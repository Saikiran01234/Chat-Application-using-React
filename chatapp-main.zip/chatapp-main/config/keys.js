module.exports = {
  mongoURI: "mongodb+srv://chat_app:chatapp@cluster0.ichwvvx.mongodb.net/fifth?retryWrites=true&w=majority",
  secretOrKey: "secret",
};
